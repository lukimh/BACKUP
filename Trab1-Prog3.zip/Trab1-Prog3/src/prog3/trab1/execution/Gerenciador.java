package prog3.trab1.execution;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintStream;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;
import prog3.trab1.dominio.Aluno;
import prog3.trab1.dominio.Avaliação;
import prog3.trab1.dominio.Avaliável;
import prog3.trab1.dominio.Curso;
import prog3.trab1.dominio.Disciplina;
import prog3.trab1.dominio.GrupoAlunos;
import prog3.trab1.dominio.Nota;
import prog3.trab1.dominio.Trabalho;
import prog3.trab1.exceptions.AvaliávelNãoFezAvaliaçãoException;
import prog3.trab1.exceptions.InserçãoInvalidaException;

/**
 * Está classe é responsável pela execução do Gerenciador de Disciplinas
 */
public class Gerenciador {

    /**
     * Armazena todas as Avaliações
     */
    public static Map<String, Avaliação> avaliacoes = new TreeMap<>();

    /**
     * Armazena todas as Disciplinas
     */
    public static Map<String, Disciplina> disciplinas = new TreeMap<>();

    /**
     * Armazena todos os Alunos
     */
    public static Map<Integer, Aluno> alunos = new TreeMap<>();

    /**
     * Armazena todos os Cursos
     */
    public static Map<Integer, Curso> cursos = new TreeMap<>();

    /**
     * Armazena o caminho da planilha de Alunos
     */
    public static String caminhoAlunos;

    /**
     * Armazena o caminho da planilha de Disciplinas
     */
    public static String caminhoDisciplinas;

    /**
     * Armazena o caminho da planilha de Avaliações
     */
    public static String caminhoAvaliações;

    /**
     * Armazena o caminho da planilha de Notas
     */
    public static String caminhoNotas;

    /**
     * Armazena o caminho da planilha de Cursos
     */
    public static String caminhoCursos;

    /**
     * Variável que define se a escrita deve ser feita com o Serializador
     */
    public static boolean escreverNoSerializador = false;

    /**
     * Variável que define se a leitura deve ser feita com o Serializador
     */
    public static boolean lerDoSerializador = false;

    /**
     * Le a planilha de disciplinas, gerando todos os objetos Disciplina para o
     * programa
     *
     * @param caminho Diretório onde se encontra a planilha
     */
    public static void leDisciplinas(String caminho) {
        try {
            Scanner in = new Scanner(new File(caminho));
            in.useDelimiter(";|\n");
            in.skip("Código;Nome\n");
            while (in.hasNext()) {
                String codigo = in.next();
                String nome = in.next();
                disciplinas.put(codigo, new Disciplina(codigo, nome));
            }
        } catch (FileNotFoundException ex) {
            System.err.println("Erro de I/O");
        }
    }

    /**
     * Le a planilha de avaliações, gerando os objetos Avaliação e adicionando
     * cada um à sua respectiva Disciplina
     *
     * @param caminho Diretório onde se encontra a planilha
     */
    public static void leAvaliações(String caminho) {
        try {
            Scanner in = new Scanner(new File(caminho));
            in.useDelimiter(";|\n");
            in.skip("Disciplina;Código;Nome;Peso;Tipo;Data;Tamanho Máximo Grupo\n");

            while (in.hasNext()) {
                Avaliação a = null;
                String códigoDisciplina = in.next();
                String código = in.next();
                String nome = in.next();
                int peso = in.nextInt();
                String tipo = in.next();
                String data = in.next();

                if (tipo.compareTo("P") == 0 || tipo.compareTo("F") == 0) {
                    a = new Avaliação(nome, código, LocalDate.parse(data, DateTimeFormatter.ofPattern("dd/MM/yyyy")), peso);
                } else if (tipo.compareTo("T") == 0) {
                    int tamGrupos = in.nextInt();
                    a = new Trabalho(tamGrupos, nome, código, LocalDate.parse(data, DateTimeFormatter.ofPattern("dd/MM/yyyy")), peso);
                }

                if (tipo.compareTo("F") == 0) {
                    disciplinas.get(códigoDisciplina).setProvaFinal(a);
                } else {
                    disciplinas.get(códigoDisciplina).adcAvaliacao(a);

                }
                avaliacoes.put(a.getCódigo(), a);

            }
        } catch (FileNotFoundException ex) {
            System.err.println("Erro de I/O");
        }
    }

    /**
     * Le a planilha de alunos, gerando os objetos Aluno e para cada aluno
     * registrando seu curso e o registrando nas disciplinas que ele está
     * matriculando
     *
     * @param caminho Diretório onde se encontra a planilha
     */
    public static void leAlunos(String caminho) {
        try (Scanner in = new Scanner(new File(caminho))) {
            in.useDelimiter(";|\n");
            in.skip("Matrícula;Nome;Disciplinas;Tipo;Curso\n");

            while (in.hasNext()) {
                Aluno a = null;

                int matricula = Integer.parseInt(in.next());
                String nome = in.next();
                String disciplinas_line = in.next();
                disciplinas_line = disciplinas_line.replace(" ", "");
                String[] códigosDisciplinas = disciplinas_line.split(",");
                String tipo = in.next();
                String curso = in.next();

                if (tipo.compareTo("G") == 0) {
                    a = new Aluno(cursos.get(Integer.parseInt(curso)), nome, matricula);
                } else if (tipo.compareTo("P") == 0) {
                    Curso c = null;
                    if (curso.compareTo("M") == 0) {
                        c = cursos.get(-2);
                    } else if (curso.compareTo("D") == 0) {
                        c = cursos.get(-1);
                    }
                    a = new Aluno(c, nome, matricula);
                }

                for (int i = 0; i < códigosDisciplinas.length; i++) {
                    disciplinas.get(códigosDisciplinas[i]).matriculaAluno(a);
                }

                alunos.put(matricula, a);

            }

        } catch (FileNotFoundException ex) {
            System.err.println("Erro de I/O");
        }
    }

    /**
     * Le a planilha de cursos, criando os objetos Curso
     *
     * @param caminho Diretório onde se encontra a planilha
     */
    private static void leCursos(String caminho) {
        try (Scanner in = new Scanner(new File(caminho))) {

            in.useDelimiter(";|\n");
            in.skip("Código;Nome\n");

            while (in.hasNext()) {
                Curso c = new Curso(in.nextInt(), in.next());
                cursos.put(c.getCodigo(), c);
            }

        } catch (FileNotFoundException ex) {
            System.err.println("Erro de I/O");
        }
    }

    /**
     * Le a planilha de notas, criando os objetos Nota e registrando o aluno que
     * as tirou, e registra as notas em suas respectivas avaliações
     *
     * @param caminho Diretório onde se encontra a planilha
     */
    private static void leNotas(String caminho) {
        //; PrintStream out = new PrintStream(new File("saida.txt"))
        try (Scanner in = new Scanner(new File(caminho))) {

            in.nextLine();
            in.useDelimiter(";|\n");

            while (in.hasNext()) {
                String códigoAvaliação = in.next();
                String alunos_line = in.next();
                alunos_line = alunos_line.replaceAll(" ", "");
                String[] matrículaAlunos = alunos_line.split(",");
                double nota = in.nextDouble();

                Avaliação a = avaliacoes.get(códigoAvaliação);

//                out.println(a.getCódigo());
                if (Trabalho.class.isInstance(a)) {
                    Trabalho t = (Trabalho) a;
                    GrupoAlunos g = new GrupoAlunos();
                    for (int i = 0; i < matrículaAlunos.length; i++) {
//                        if(matrículaAlunos[i].equals("2000991375")){
//                            out.println("GORDOM");
//                        }
                        try {
//                            out.println("\t-" + matrículaAlunos[i] + "-");
                            g.adcAluno(alunos.get(Integer.parseInt(matrículaAlunos[i])));
                        } catch (InserçãoInvalidaException e) {
                            System.err.println(e);
                        }
                    }

                    try {
                        t.registraGrupo(g);
                        t.registraNota(g, new Nota(nota));
//                        out.println("\tNOTA: " + nota);
                    } catch (InserçãoInvalidaException ex) {
                        System.err.println(ex);
                    }

                } else if (Avaliação.class.isInstance(a)) {
//                    out.println("\t-" + matrículaAlunos[0] + "-");
                    a.registraNota(alunos.get(Integer.parseInt(matrículaAlunos[0])), new Nota(nota));
//                    out.println("\tNOTA: " + nota);
                }
            }

        } catch (FileNotFoundException ex) {
            System.err.println("Erro de I/O");
        }
    }

    /**
     * Faz a leitura de um arquivo de Serialização para gerar os objetos
     * necessários para a execução do programa
     */
    private static void leSerializaçao() {
        try (   FileInputStream arquivoLeitura = new FileInputStream("serialização.dat");
                ObjectInputStream objLeitura = new ObjectInputStream(arquivoLeitura)){

            System.out.println(objLeitura.readObject());

            
            disciplinas = (Map<String, Disciplina>) objLeitura.readObject();
            avaliacoes = (Map<String, Avaliação>) objLeitura.readObject();
            cursos = (Map<Integer, Curso>) objLeitura.readObject();
            alunos = (Map<Integer, Aluno>) objLeitura.readObject();
            
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Erro de I/O");
        }
    }

    /**
     * Função principal do programa, responsável por receber os parametros da
     * execução do programa e interpreta-los
     *
     * @param args Paramtros da linha de comando da execução do programa
     */
    public static void main(String[] args) {
        Locale.setDefault(new Locale("pt", "BR"));
        for (int i = 0; i < args.length; i++) {
            switch (Comando.obtemComando(args[i])) {
                case AJUDA:
                    System.out.println("-------------------------");
                    System.out.println("GERENCIADOR DE DISCIPLINA");
                    System.out.println("-------------------------");
                    System.out.println();
                    for (Comando c : Comando.values()) {
                        System.out.println(c);
                        System.out.println();
                    }
                    System.exit(0);
                case LER_ALUNOS:
                    caminhoAlunos = args[++i];
                    break;
                case LER_NOTAS:
                    caminhoNotas = args[++i];
                    break;
                case LER_AVALIAÇÕES:
                    caminhoAvaliações = args[++i];
                    break;
                case LER_CURSOS:
                    caminhoCursos = args[++i];
                    break;
                case LER_DISCIPLINAS:
                    caminhoDisciplinas = args[++i];
                    break;
                case SOMENTE_ESCRITA:
                    lerDoSerializador = true;
                    break;
                case SOMENTE_LEITURA:
                    escreverNoSerializador = true;
                    break;
                case DESCONHECIDO:
                    System.err.println("Comando desconhecido: " + args[i]);
            }
        }

        if (!lerDoSerializador) {
            leDisciplinas(caminhoDisciplinas);
            leAvaliações(caminhoAvaliações);
            leCursos(caminhoCursos);
            cursos.put(-1, new Curso(-1, "Mestrado"));
            cursos.put(-2, new Curso(-2, "Doutorado"));
            leAlunos(caminhoAlunos);
            leNotas(caminhoNotas);
            for (Disciplina d : disciplinas.values()) {
                avaliacoes.remove(d.getProvaFinal().getCódigo());
            }
        } else {
            leSerializaçao();
        }

        System.out.println("gsahdjkl");
        for(Map.Entry<Avaliável, Nota> map : avaliacoes.get("DWWS-T1").getNotas().entrySet()){
            System.out.println(map.getKey() + "\n\t" + map.getValue());
        }
        
        for(Map.Entry<Avaliável, Nota> map : avaliacoes.get("DWWS-T2").getNotas().entrySet()){
            System.out.println(map.getKey() + " " + map.getValue());
        }
        
        if (!escreverNoSerializador) {
            for (Disciplina d : disciplinas.values()) {
                if (d.equals(disciplinas.get("INF09373"))) {
                    System.out.println("HELLO");
                }
                geraPauta("", d);
            }
            geraEstatísticasAvaliações("");
            geraEstatísticasDisciplinas("");
        } else {
            escreveSerialização();
        }

    }

    /**
     * 
     */
    public static void escreveSerialização() {
        try ( //Gera o arquivo para armazenar o objeto
                FileOutputStream arquivoGrav = new FileOutputStream("serialização.dat");
                //Classe responsavel por inserir os objetos
                ObjectOutputStream objGravar = new ObjectOutputStream(arquivoGrav)) {

            //Grava o objeto cliente no arquivo
            objGravar.writeObject(disciplinas);
            objGravar.writeObject(avaliacoes);
            objGravar.writeObject(cursos);
            objGravar.writeObject(alunos);
            objGravar.flush();
            arquivoGrav.flush();

        } catch (IOException e) {
            System.out.println("Erro de I/O");
        }
    }

    /**
     * Gera uma planilha que contém a pauta de uma disciplina
     *
     * @param caminho Diretório onde a planilha será salva
     * @param disciplina Disciplina da qual será gerada a pauta
     */
    public static void geraPauta(String caminho, Disciplina disciplina) {
        //if(disciplina.equals(alunos))
        StringBuilder planilha = new StringBuilder("Matrícula;Aluno;");
        List<Avaliação> avaliações = disciplina.getAvaliacoes();
        avaliações.sort((Avaliação a1, Avaliação a2) -> a1.getData().compareTo(a2.getData()));
        for (Avaliação av : avaliações) {
            planilha.append(av.getCódigo()).append(";");
        }
        planilha.append("Média Parcial;Prova Final;Média Final\n");
        List<Aluno> alunos = disciplina.getAlunos();
        alunos.sort((Aluno a1, Aluno a2) -> a1.getNome().compareTo(a2.getNome()));
        for (Aluno a : alunos) {
            int mat = a.getMatricula();
            String nome = a.getNome();

            planilha.append(mat).append(";");
            planilha.append(nome).append(";");

            for (Avaliação av : avaliações) {
                try {
                    double nota = av.getNota(a).getValor();
                    planilha.append(String.format("%.2f;", nota));
                } catch (AvaliávelNãoFezAvaliaçãoException e) {
                    e.printStackTrace(System.out);
                    System.out.println(av + " for " + a);
                    planilha.append(String.format("%.2f;", (double) 0));
                }
            }

            double mediaParcial = disciplina.getMediaParcialAluno(a);
            double mediaFinal = disciplina.getMediaAluno(a);

            planilha.append(String.format("%.2f;", mediaParcial));
            try {
                planilha.append(String.format("%.2f;", disciplina.getProvaFinal().getNota(a).getValor()));
            } catch (AvaliávelNãoFezAvaliaçãoException ex) {
                if (mediaParcial < 7) {
                    planilha.append("0,00;");
                } else {
                    planilha.append("-;");
                }
            }

            planilha.append(String.format("%.2f\n", mediaFinal));
        }

        try (PrintStream out = new PrintStream(new File(caminho + "1-pauta-" + disciplina.getCodigo() + ".csv"))) {
            out.print(planilha);
        } catch (FileNotFoundException ex) {
            System.err.println("Erro de I/O");
        }
    }

    /**
     * Gera uma planilha que contém estatísticas de todas as disciplinas
     *
     * @param caminho Diretório onde a planilha será salva
     */
    public static void geraEstatísticasDisciplinas(String caminho) {
        StringBuilder planilha = new StringBuilder("Código;Disciplina;Curso;Média;% Aprovados\n");

        List<Disciplina> disciplinas = new ArrayList<>(Gerenciador.disciplinas.values());
        disciplinas.sort(Disciplina::compareTo);

        for (Disciplina d : disciplinas) {
            List<Curso> cursosEnv = d.getCursosEnvolvidos();
            cursosEnv.sort((Curso o1, Curso o2) -> Double.compare(d.media(o2), d.media(o1)));
            for (Curso c : cursosEnv) {
                planilha.append(d.getCodigo()).append(";");
                planilha.append(d.getNome()).append(";");
                planilha.append(c.getNome()).append(";");
                planilha.append(String.format("%.2f", d.media(c))).append(";");
                planilha.append(String.format("%.1f", d.taxaAprovados() * 100.0)).append("%\n");
            }
        }

        try (PrintStream out = new PrintStream(new File(caminho + "2-disciplinas.csv"))) {
            out.print(planilha);
        } catch (FileNotFoundException ex) {
            System.err.println("Erro de I/O");
        }
    }

    /**
     * Gera uma planilha que contém estatísticas de todas as avaliações
     *
     * @param caminho Diretório onde a planilha será salva
     */
    public static void geraEstatísticasAvaliações(String caminho) {
        StringBuilder planilha = new StringBuilder("Disciplina;Código;Avaliação;Data;Média\n");
        List<Disciplina> disciplinas = new ArrayList<>(Gerenciador.disciplinas.values());
        disciplinas.sort(Disciplina::compareTo);
        for (Disciplina d : disciplinas) {
            List<Avaliação> avaliações = d.getAvaliacoes();

            avaliações.sort((Avaliação o1, Avaliação o2) -> o1.getData().compareTo(o2.getData()));

            for (Avaliação a : avaliações) {
                planilha.append(d.getCodigo()).append(";");
                planilha.append(a.getCódigo()).append(";");
                planilha.append(a.getNome()).append(";");
                planilha.append(a.getData().format(DateTimeFormatter.ofPattern("dd/MM/yyyy;")));
                planilha.append(String.format("%.2f\n", a.media()));
            }
        }
        try (PrintStream out = new PrintStream(new File(caminho + "3-avaliacoes.csv"))) {
            out.print(planilha);
        } catch (FileNotFoundException ex) {
            System.err.println("Erro de I/O");
        }
    }
}
