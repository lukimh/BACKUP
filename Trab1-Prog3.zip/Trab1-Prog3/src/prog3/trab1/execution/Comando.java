package prog3.trab1.execution;

import java.io.Serializable;

/**
 * Enumeração de comandos que podem ser passados na linha de execução do
 * programa
 */
public enum Comando{
    /**
     * Comando para passar o diretório da planilha de Avaliações
     */
    LER_AVALIAÇÕES("-p", "Define a planilha de avaliações como o arquivo \"CAMINHO_ARQUIVO\"", "[CAMINHO_ARQUIVO]"),
    /**
     * Comando para passar o diretório da planilha de Alunos
     */
    LER_ALUNOS("-a", "Define a planilha de alunos como o arquivo \"CAMINHO_ARQUIVO\"", "[CAMINHO_ARQUIVO]"),
    /**
     * Comando para passar o diretório da planilha de Disciplinas
     */
    LER_DISCIPLINAS("-d", "Define a planilha de disciplinas como o arquivo \"CAMINHO_ARQUIVO\"", "[CAMINHO_ARQUIVO]"),
    /**
     * Comando para passar o diretório da planilha de Cursos
     */
    LER_CURSOS("-c", "Define a planilha de cursos como o arquivo \"CAMINHO_ARQUIVO\"", "[CAMINHO_ARQUIVO]"),
    /**
     * Comando para passar o diretório da planilha de Notas
     */
    LER_NOTAS("-n", "Define a planilha de notas como o arquivo \"CAMINHO_ARQUIVO\"", "[CAMINHO_ARQUIVO]"),
    /**
     * Comando para salvar toda a leitura para um arquivo Serializado
     */
    SOMENTE_LEITURA("--read-only", "Salva toda a leitura para um arquivo serializado (Depende das outras funções de leitura)"),
    /**
     * Comando para realizar a leitura a partir de um arquivo Serializado
     */
    SOMENTE_ESCRITA("--write-only", "Realiza a leitura a partir de um arquivo serializado (Não depende das outras funções de leitura)"),
    
    /**
     * Comando que exibe todos os comandos disponíveis
     */
    AJUDA("--help", "Abre esta ajuda"),
    
    /**
     * Comando desconhecido
     */
    DESCONHECIDO("", "");

    /**
     * O Comando em si
     */
    private final String comando;

    /**
     * Descrição do comando
     */
    private final String descrição;

    /**
     * Lista de argumentos do comando
     */
    private final String[] argumentos;

    /**
     * Construtor padrão, que gera os casos da enumeração
     *
     * @param comando O comando em si
     * @param descrição A descrição do comando
     * @param argumentos Lista de argumentos do comando
     */
    private Comando(String comando, String descrição, String... argumentos) {
        this.comando = comando;
        this.descrição = descrição;
        this.argumentos = argumentos;
    }

    /**
     * Gera uma descrição do comando:
     * <p>
     * <i>[COMANDO] [ARGUMENTO_1]...[ARGUMENTO_N] : [DESCRIÇÃO]</i>
     * </p>
     *
     * @return Uma string com a descrição
     */
    @Override
    public String toString() {
        if (this == DESCONHECIDO) {
            return "";
        }
        StringBuilder str = new StringBuilder(comando);
        for (String s : argumentos) {
            str.append(" ").append(s);
        }
        str.append(" : ").append(descrição);
        return str.toString();
    }

    /**
     * Retorna o comando que está contido em uma string, sem diferenciar
     * maiúsculas e minúsculas
     *
     * @param cmd Uma String contendo o comando
     * @return O comando econtrado na String, ou Comando.DESCONHECIDO se não
     *         encontrar nenhum
     */
    public static Comando obtemComando(String cmd) {
        int idx = cmd.indexOf(' ');
        if (idx != -1) {
            cmd = cmd.substring(0, idx);
        }
        cmd = cmd.toLowerCase();
        for (Comando comando : Comando.values()) {
            if (comando.comando.equals(cmd)) {
                return comando;
            }
        }
        return DESCONHECIDO;
    }
}
