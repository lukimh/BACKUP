package prog3.trab1.dominio;

import java.io.Serializable;

/**
 *
 * @author lukimh
 */
public class Nota implements Serializable, Comparable<Nota> {

    /**
     * O valor da nota em si
     */
    private final double valor;

    /**
     *
     * @param nota
     */
    public Nota(double nota) {
        if (nota < 0) {
            throw new IllegalArgumentException("Nota invalida");
        }
        this.valor = nota;
    }

    /**
     * Retorna o valor da nota
     *
     * @return Um double com o valor da nota
     */
    public double getValor() {
        return valor;
    }

    /**
     * Compara esta nota com outra pelo valor
     *
     * @param outraNota A nota com a qual comparamos esta
     * @return      <pre>
     *  Um inteiro 'i' para os seguintes casos:
     *      i > 0  - Caso esta nota seja maior que a outra
     *
     *      i == 0 - Caso as notas sejam iguais
     *
     *      i &lt; 0  - Caso esta nota seja menor que a outra
     * </pre>
     */
    @Override
    public int compareTo(Nota outraNota) {
        return Double.compare(valor, outraNota.valor);
    }
    
    @Override
    public String toString() {
        return Double.toString(valor);
    }
}
