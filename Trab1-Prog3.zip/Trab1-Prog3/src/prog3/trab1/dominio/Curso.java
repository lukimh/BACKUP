package prog3.trab1.dominio;

import java.util.ArrayList;
import java.util.List;

/**
 * Esta classe representa um curso que os alunos possam estar matrículados
 */
public class Curso {

    /**
     * Código do curso
     */
    private final int codigo;

    /**
     * Nome do curso
     */
    private String nome;

    /**
     * Constrói um novo curso
     *
     * @param codigo Código do curso
     * @param nome Nome do curso
     */
    public Curso(int codigo, String nome) {
        this.codigo = codigo;
        this.nome = nome;
    }

    /**
     * Obtém o código do Curso
     *
     * @return Um inteiro que contem o código do curso
     */
    public int getCodigo() {
        return codigo;
    }

    /**
     * Obtém o nome do curso
     *
     * @return Uma String contendo o nome do curso
     */
    public String getNome() {
        return nome;
    }

    @Override
    public String toString() {
        return "(" + this.codigo + ") " + this.nome;
    }

    /**
     * Checa se um curso é igual a outro checando se os seus códigos são iguais
     *
     * @param obj Curso, com o qual este será comparado
     * @return <pre> true - Se os códigos forem iguais e portanto os cursos também
     * false - Se os códigos forem diferentes e portanto os cursos também </pre>
     */
    @Override
    public boolean equals(Object obj) {
        return codigo == ((Curso) obj).codigo;
    }
}
