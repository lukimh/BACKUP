package prog3.trab1.dominio;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import prog3.trab1.exceptions.InserçãoInvalidaException;

/**
 * Classe que representa um grupo de alunos para um Trabalho
 */
public class GrupoAlunos implements Avaliável, Serializable, Comparable<GrupoAlunos> {

    /**
     * Lista de alunos que estão neste grupo
     */
    private final List<Aluno> alunos;

    /**
     * Constroi um novo grupo, sem nenhum aluno
     */
    public GrupoAlunos() {
        alunos = new ArrayList<>();
    }

    /**
     * Adiciona um aluno ao grupo
     *
     * @param aluno Aluno que será adicionado
     * @throws InserçãoInvalidaException Caso aluno seja inválido (null)
     */
    public void adcAluno(Aluno aluno) throws InserçãoInvalidaException {
        if (aluno == null) {
            throw new InserçãoInvalidaException("Aluno adicionado é invalido");
        }
        alunos.add(aluno);
    }

    /**
     * Obtem a lista de alunos.
     *
     * @return Um ArrayList contendo os alunos
     */
    public List<Aluno> getAlunos() {
        return new ArrayList<>(alunos);
    }

    @Override
    public String toString() {
        StringBuilder s = new StringBuilder("Grupo:\n");
        for (Aluno a : alunos) {
            s.append("\t\t").append(a).append("\n");
        }
        return s.substring(0, s.length() - 1);
    }

    /**
     * Compara os grupos de alunos pelo tamanho
     *
     * @param outroGrupo Grupo com o qual se deseja comparar este
     * @return      <pre>
     *  Um inteiro 'i' para os seguintes casos:
     *      i &gt; 0  - Caso seja o tamanho deste grupo seja maior que o do outro
     *
     *      i == 0 - Caso os tamanho dos grupos sejam iguais
     *
     *      i &lt; 0  - Caso seja o tamanho deste grupo seja menor que o do outro
     * </pre>
     */
    @Override
    public int compareTo(GrupoAlunos outroGrupo) {
        int this_size = this.alunos.size();
        int other_size = outroGrupo.alunos.size();
        if (this_size == other_size){
            if(alunos.containsAll(outroGrupo.alunos)){
                return 0;
            } else {
                return 1;
            }
        } else {
            return this_size - other_size;
        }
    }

    /**
     * Obtem o número de alunos no grupo
     *
     * @return um inteiro com essa quantidade
     */
    public int numAlunos() {
        return alunos.size();
    }

    /**
     * Checa se um aluno esta no grupo
     *
     * @param a Aluno a ser encontrado
     * @return true - Aluno está no grupo<br>
     * false - Aluno não está do grupo
     */
    public boolean contémAluno(Aluno a) {
        return alunos.contains(a);
    }

    /**
     * Checa se dois grupos são os mesmos
     *
     * @param outroGrupo Grupo com o qual este será comparado
     * @return true - Se os dois grupos tiverem os mesmos alunos<br>
     * false - Se os dois grupos não tenham os mesmos alunos
     */
    @Override
    public boolean equals(Object outroGrupo) {
        GrupoAlunos outro = (GrupoAlunos) outroGrupo;
        if (numAlunos() != outro.numAlunos()) {
            return false;
        }

        return alunos.containsAll(outro.getAlunos());
    }
}
