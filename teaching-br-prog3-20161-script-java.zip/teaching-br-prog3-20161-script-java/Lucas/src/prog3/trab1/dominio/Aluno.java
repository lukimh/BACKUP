package prog3.trab1.dominio;

import java.io.Serializable;

/**
 * Esta classe representa um aluno que cursará disciplinas e será avaliado
 */
public class Aluno implements Avaliável, Comparable<Aluno>, Serializable {

    /**
     * Nome do aluno
     */
    private final String nome;

    /**
     * Matrícula do aluno
     */
    private final int matricula;

    /**
     * Curso do aluno
     */
    private final Curso curso;

    /**
     * Constrói um novo aluno
     *
     * @param curso Curso do aluno
     * @param nome Nome do aluno
     * @param matricula Matrícula do aluno
     */
    public Aluno(Curso curso, String nome, int matricula) {
        this.nome = nome;
        this.matricula = matricula;
        this.curso = curso;
    }

    /**
     * Obtém a matrícula do aluno
     *
     * @return Um inteiro contendo a matrícula
     */
    public int getMatricula() {
        return matricula;
    }

    /**
     * Obtém o nome do aluno
     *
     * @return Uma String contendo a matrícula
     */
    public String getNome() {
        return nome;
    }

    /**
     * Obtém o curso que o aluno está matriculado
     *
     * @return O Curso
     */
    public Curso getCurso() {
        return curso;
    }

    @Override
    public String toString() {
        return this.getMatricula() + " - " + this.getNome() + "\n\t\tCursando " + getCurso();
    }

    /**
     * Compara dois alunos pela matrícula
     *
     * @param outroAluno Aluno com o qual se deseja comparar este
     * @return <pre>Um inteiro 'i' para os seguintes casos:
     *      i &gt; 0  - Caso seja a matrícula deste aluno seja maior que a do outro
     *
     *      i == 0 - Caso as matrículas dos alunos sejam iguais
     *
     *      i &lt; 0  - Caso seja a matrícula deste aluno seja menor que a do outro
     * </pre>
     */
    @Override
    public int compareTo(Aluno outroAluno) {
        return matricula - outroAluno.matricula;
    }

    /**
     * Checa se dois alunos são os mesmos
     * 
     * @param outroAluno
     * @return true - Se eles forem os mesmos
     * <br>false - Se eles não forem os mesmos
     */
    @Override
    public boolean equals(Object outroAluno) {
        Aluno outro = (Aluno)outroAluno;
        return matricula == outro.matricula;
    }

}
