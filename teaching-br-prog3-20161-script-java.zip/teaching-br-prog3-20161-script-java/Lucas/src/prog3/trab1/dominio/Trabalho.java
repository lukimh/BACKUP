package prog3.trab1.dominio;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import prog3.trab1.exceptions.AvaliávelInválidoException;
import prog3.trab1.exceptions.AvaliávelNãoFezAvaliaçãoException;
import prog3.trab1.exceptions.InserçãoInvalidaException;
import prog3.trab1.exceptions.NotaInválidaException;

/**
 * Esta classe representa Avalição do tipo Trabalho em grupo
 */
public class Trabalho extends Avaliação implements Serializable {

    /**
     * Número máximo de membros de um grupo
     */
    private final int tamMaxGrupos;

    /**
     * Lista de Grupos que estão realizando este trabalho
     */
    private final List<GrupoAlunos> grupos;

    /**
     * Constrói uma avaliação do tipo Trabalho em Grupo
     *
     * @param tamMaxGrupos Número máximo de membros de um grupo
     * @param nome Nome do Trabalho
     * @param código Código do Trabalho
     * @param data Data de entrega do trabalho
     * @param peso Peso que o trabalho tem sobre a média de uma Disciplina
     */
    public Trabalho(int tamMaxGrupos, String nome, String código, LocalDate data, int peso) {
        super(nome, código, data, peso);

        if (tamMaxGrupos <= 0) {
            throw new IllegalArgumentException("Tamanho máximo dos Grupos "
                    + "invalido: " + tamMaxGrupos);
        }

        this.tamMaxGrupos = tamMaxGrupos;
        grupos = new ArrayList<>();
    }

    /**
     * Obtém o número máximo de membros que um grupo pode ter
     *
     * @return Um inteiro com esse número
     */
    public int getTamMaxGrupos() {
        return tamMaxGrupos;
    }

    /**
     * Obvtem a lista de alunos que estão realizando trabalho neste grupo
     *
     * @return Um ArrayList contendo todos os grupos
     */
    public List<GrupoAlunos> getGrupos() {
        return new ArrayList<>(grupos);
    }

    /**
     * Registra um grupo no trabalho
     *
     * @param grupo Grupo de Alunos a ser registrado
     * @throws InserçãoInvalidaException se o número de alunos no grupo for
     * maior que o número máximo para o trabalho
     */
    public void registraGrupo(GrupoAlunos grupo) throws InserçãoInvalidaException {
        if (grupo.numAlunos() > tamMaxGrupos) {
            throw new InserçãoInvalidaException("Numero máximo de alunos atingidos"
                    + " para grupo no trabalho: " + this.getNome());
        }
        for (GrupoAlunos g : grupos) {
            for (Aluno a : grupo.getAlunos()) {

                if (g.contémAluno(a)) {
                    throw new InserçãoInvalidaException("Aluno já está em outro grupo");
                }
            }
        }
        if (!grupos.contains(grupo)) {
            grupos.add(grupo);
        }
    }

    @Override
    public void registraNota(Avaliável avaliado, Nota nota) throws AvaliávelInválidoException, NotaInválidaException {
        if (grupos.contains((GrupoAlunos) avaliado)) {
            super.registraNota(avaliado, nota);
        } else {
            throw new InserçãoInvalidaException("Grupo não está realizando trabalho");
        }
    }

    /**
     * Calcula a nota de um objeto Avaliável
     *
     * @param a Objeto do qual se deseja saber a nota
     * @return A nota deste objeto
     * @throws AvaliávelNãoFezAvaliaçãoException caso o Avaliável em questão,
     * não tiver feito o trabalho
     */
    @Override
    public Nota getNota(Avaliável a) throws AvaliávelNãoFezAvaliaçãoException {
        if (GrupoAlunos.class.isInstance(a)) {
            return super.getNota(a);
        } else if (Aluno.class.isInstance(a)) {
            for (GrupoAlunos g : grupos) {
                if (g.contémAluno((Aluno)a)) {
                    return super.getNota(g);
                }
            }
        }
        throw new AvaliávelNãoFezAvaliaçãoException("O Avaliável " + a + " não fez o trabalho" + this);
    }
}
