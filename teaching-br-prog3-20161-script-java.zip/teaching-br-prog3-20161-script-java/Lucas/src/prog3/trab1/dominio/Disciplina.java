package prog3.trab1.dominio;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import prog3.trab1.exceptions.AvaliávelInválidoException;
import prog3.trab1.exceptions.AvaliávelNãoFezAvaliaçãoException;
import prog3.trab1.exceptions.InserçãoInvalidaException;

/**
 *
 * @author lukimh
 */
public class Disciplina implements Serializable, Comparable<Disciplina> {

    /**
     * Nome da disciplina
     */
    private final String nome;

    /**
     * Código da disciplina
     */
    private final String codigo;

    /**
     * Lista de avaliações que serão aplicadas na disciplina
     */
    private final List<Avaliação> avaliacoes;

    /**
     * Avaliação a ser aplicada para aqueles que não passarem direto com média 7
     */
    private Avaliação provaFinal;

    /**
     * Lista de alunos matrículados na disciplina
     */
    private final List<Aluno> alunos;

    /**
     * Lista de cursos dos alunos matrículados
     */
    private final List<Curso> cursosEnvolvidos;

    /**
     * Constrói uma nova disciplina sem avaliações ou alunos matrículados
     *
     * @param codigo Código da Disciplina
     * @param nome Nome da Disciplina
     */
    public Disciplina(String codigo, String nome) {
        this.nome = nome;
        this.codigo = codigo;
        alunos = new ArrayList<>();
        avaliacoes = new ArrayList<>();
        cursosEnvolvidos = new ArrayList<>();
    }

    /**
     * Obtém o nome da Disciplina
     *
     * @return Uma String contendo o nome da disciplina
     */
    public String getNome() {
        return new String(nome);
    }

    /**
     * Obtém o código da Disciplina
     *
     * @return Uma String contendo o código da disciplina
     */
    public String getCodigo() {
        return new String(codigo);
    }

    /**
     * Obtém uma lista das avaliações que serão aplicadas na disciplina
     *
     * @return Um ArrayList contendo estas avaliações
     */
    public List<Avaliação> getAvaliacoes() {
        return new ArrayList<>(avaliacoes);
    }

    /**
     * Obtém a prova final da disciplina
     *
     * @return A Avaliação que foi definida como prova final
     */
    public Avaliação getProvaFinal() {
        return provaFinal;
    }

    /**
     * Obtém a lista de alunos matrículados na disciplina
     *
     * @return Um ArrayList contendo estes alunos
     */
    public List<Aluno> getAlunos() {
        return new ArrayList<>(alunos);
    }

    /**
     * Obtém a lista de cursos, os quais tem alunos nessa disciplina
     *
     * @return Um ArrayList contendo estes cursos
     */
    public List<Curso> getCursosEnvolvidos() {
        return new ArrayList<>(cursosEnvolvidos);
    }

    /**
     * Define qual é a prova final
     *
     * @param provaFinal A avaliação que será dada como prova final
     */
    public void setProvaFinal(Avaliação provaFinal) {
        this.provaFinal = provaFinal;
    }

    /**
     * Registra uma avaliação como uma a ser aplicada nesta disciplina
     *
     * @param avaliação Avaliação a ser registrada
     * @throws InserçãoInvalidaException Caso a avaliação seja inválida (null)
     * ou<br> caso ela já esteja registrada nesta disciplina
     */
    public void adcAvaliacao(Avaliação avaliação) throws InserçãoInvalidaException {
        if (avaliação == null) {
            throw new InserçãoInvalidaException("Avaliação inválida");
        }
        if (avaliacoes.contains(avaliação)) {
            throw new InserçãoInvalidaException("Avaliacao " + avaliação + " já presente em " + this);
        }
        this.avaliacoes.add(avaliação);
    }

    /**
     * Matricula um aluno na Disciplina
     *
     * @param aluno Aluno a ser matriculado
     * @throws InserçãoInvalidaException Caso o aluno seja inválido (null)
     * ou<br> caso ele já esteja matriculado nesta disciplina
     */
    public void matriculaAluno(Aluno aluno) throws InserçãoInvalidaException {
        if (aluno == null) {
            throw new InserçãoInvalidaException("Aluno invalida");
        }
        if (alunos.contains(aluno)) {
            throw new InserçãoInvalidaException("Aluno já matriculado em " + this);
        }
        this.alunos.add(aluno);
        if (!cursosEnvolvidos.contains(aluno.getCurso())) {
            this.cursosEnvolvidos.add(aluno.getCurso());
        }
    }

    /**
     * Calcula a média das notas dos alunos que sejam de um determinado curso
     * nessa disiciplina
     *
     * @param curso Curso do qual se deseja saber a média
     * @return Um double contendo a média
     */
    public double media(Curso curso) {
        double media = 0;
        int numAlunos = 0;
        for (Aluno a : alunos) {
            if (a.getCurso().equals(curso)) {
                media += this.getMediaAluno(a);
                numAlunos++;
            }
        }
        return media / numAlunos;
    }

    /**
     * Calcula a média das notas dos alunos dessa disiciplina
     *
     * @return Um double contendo a média
     */
    public double media() {
        double media = 0;
        for (Aluno a : alunos) {
            media += getMediaAluno(a);
        }
        return media / this.alunos.size();
    }

    /**
     * Calcula a taxa de alunos que sejam de um determinado curso que foram
     * aprovados nessa disiciplina
     *
     * @param c Curso, do qual se deseja saber a taxa
     * @return Um double entre 0 e 1:<pre>
     *          1 - Todos os alunos aprovados
     *          0 - Nenhum aluno aprovado</pre>
     */
    public double taxaAprovados(Curso c) {
        double numAprovados = 0.0;
        double totalAlunosCurso = 0.0;
        for (Aluno a : alunos) {
            if (a.getCurso().equals(c)) {
                if (getMediaAluno(a) >= 5) {
                    numAprovados++;
                }
                totalAlunosCurso++;
            }
        }
        return numAprovados / totalAlunosCurso;
    }

    /**
     * Calcula a taxa de alunos que foram aprovados nessa disiciplina
     *
     * @return Um double entre 0 e 1:<pre>
     *          1 - Todos os alunos aprovados
     *          0 - Nenhum aluno aprovado
     * </pre>
     */
    public double taxaAprovados() {
        int numAprovados = 0;
        for (Aluno a : alunos) {
            if (getMediaAluno(a) >= 5) {
                numAprovados++;
            }
        }
        return (double) numAprovados / this.alunos.size();
    }

    @Override
    public String toString() {
        return this.codigo + "\t\t" + this.nome;
    }

    /**
     * Compara duas disicplinas pelo código
     *
     * @param outraDisciplina Disiciplina com a qual comparamos esta
     * @return      <pre>
     *  Um inteiro 'i' para os seguintes casos:
     *      i &gt; 0  - Caso seja o código desta disciplina seja lecoxigráficamente
     *               maior que o da outra
     *
     *      i == 0 - Caso os códigos das disciplinas sejam iguais
     *
     *      i &lt; 0  - Caso seja o código desta disciplina seja lecoxigráficamente
     *               menor que o da outra
     * </pre>
     */
    @Override
    public int compareTo(Disciplina outraDisciplina) {
        return this.codigo.compareTo(outraDisciplina.codigo);
    }

    /**
     * Calcula a média parcial de um aluno na Disciplina
     *
     * @param aluno Aluno do qual se deseja saber a média
     * @return Um double de 0 a 10 contendo a média parcial
     */
    public double getMediaParcialAluno(Aluno aluno) {
        if (aluno == null) {
            throw new AvaliávelInválidoException("Aluno invalido");
        }
        double sumNotas = 0;
        int sumPesos = 0;
        for (Avaliação avaliação : avaliacoes) {
            int peso = avaliação.getPeso();
            try {

                sumNotas += avaliação.getNota(aluno).getValor() * peso;

            } catch (AvaliávelNãoFezAvaliaçãoException e) {
                sumNotas += 0; //Trata como aluno tirou zero
            }
            sumPesos += peso;
        }
        return sumNotas / sumPesos;
    }

    /**
     * Calcula a média final de um aluno nessa disciplina
     *
     * @param aluno Aluno do qual se deseja saber a médi
     * @return <pre> O retorno será igual ao de <strong><i>getMediaParcial(aluno)</i></strong> caso este seja &gt;= 7
     * Caso contrário retorna a média aritimética de <strong><i>getMediaParcial(aluno)</i></strong> e <strong><i>provaFinal.getNota(aluno)</i></strong>
     * Caso o aluno não tenha feito provaFinal retorna (<strong><i>getMediaParcial(aluno) / 2</i></strong>)</pre>
     *
     * @see #getMediaParcialAluno(Aluno)
     * @see Avaliação#getNota(Avaliável) 
     */
    public double getMediaAluno(Aluno aluno) {
        if (aluno == null) {
            throw new AvaliávelInválidoException("Aluno invalido");
        }
        double media = getMediaParcialAluno(aluno);
        if (media >= 7) {
            return media;
        } else {
            try {
                media = (provaFinal.getNota(aluno).getValor() + media) / 2;
            } catch (AvaliávelNãoFezAvaliaçãoException e) {
                media /= 2;
            } catch (NullPointerException e) {
                System.err.println(e);
            }
            return media;
        }
    }

    @Override
    public boolean equals(Object outraDisciplina) {
        Disciplina outra = (Disciplina)outraDisciplina;
        return codigo == outra.codigo;
    }
}
