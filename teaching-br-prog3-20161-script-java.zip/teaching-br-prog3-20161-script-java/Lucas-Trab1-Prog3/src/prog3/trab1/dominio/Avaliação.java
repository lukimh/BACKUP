package prog3.trab1.dominio;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Map;
import java.util.TreeMap;
import prog3.trab1.exceptions.AvaliávelNãoFezAvaliaçãoException;
import prog3.trab1.exceptions.AvaliávelInválidoException;
import prog3.trab1.exceptions.InserçãoInvalidaException;
import prog3.trab1.exceptions.NotaInválidaException;

/**
 * Esta classe define uma avaliação que será aplicada em uma disciplina
 */
public class Avaliação implements Comparable<Avaliação> {

    /**
     * Nome da avaliação
     */
    private final String nome;

    /**
     * Código da avaliação
     */
    private final String código;

    /**
     * Data da realização/entrega da avaliação
     */
    private final LocalDate data;

    /**
     * Peso que esta avaliação tem na média de uma disciplina
     */
    private final int peso;

    /**
     * Lista de notas desta avaliação atribuídas a objetos Avaliáveis
     */
    private final Map<Avaliável, Nota> notas;

    /**
     * Constrói uma avaliação sem nenhuma nota registada
     *
     * @param nome Nome da avaliação
     * @param código Código da avaliação
     * @param data Data da realização/entrega da avaliação
     * @param peso Peso da avaliação
     */
    public Avaliação(String nome, String código, LocalDate data, int peso) {
        this.nome = nome;
        this.código = código;
        this.data = data;
        this.peso = peso;
        this.notas = new TreeMap<>();
    }

    /**
     * Obtém o nome da avaliação
     *
     * @return Uma String com o nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * Obtém o código da avaliação
     *
     * @return Uma String que contém o código
     */
    public String getCódigo() {
        return código;
    }

    /**
     * Obtém a data de realização/entrega desta avaliação
     *
     * @return A data
     */
    public LocalDate getData() {
        return data;
    }

    /**
     * Obtém o peso da avaliação
     *
     * @return Um inteiro contendo o peso
     */
    public int getPeso() {
        return peso;
    }

    /**
     * Otém a nota de um objeto avaliável
     *
     * @param avaliado Objeto avaliável do qual se deseja saber a nota
     * @return A Nota desse objeto
     * @throws AvaliávelNãoFezAvaliaçãoException Caso este objeto Avaliável não
     * tiver uma nota registrada nessa avaliação
     */
    public Nota getNota(Avaliável avaliado) throws AvaliávelNãoFezAvaliaçãoException {
        if (notas.containsKey(avaliado)) {
            return notas.get(avaliado);
        } else {
            throw new AvaliávelNãoFezAvaliaçãoException("Não existe nota para "
                    + avaliado + " em " + this);
        }
    }

    /**
     * Obtém a lista de notas registradas nessa avaliação
     *
     * @return Um TreeMap contendo todas as notas, com chave sendo o Avaliável
     * que a recebeu
     * @see Map
     */
    public Map<Avaliável, Nota> getNotas() {
        return new TreeMap<>(notas);
    }

    /**
     * Registra a nota de um objeto avaliável nesta avaliação
     *
     * @param avaliado Objeto avaliável do qual se deseja registrar a nota
     * @param nota Nota desse objeto nesta avaliação
     * @throws AvaliávelInválidoException Caso avaliado seja inválido (null)
     * @throws NotaInválidaException Caso nota seja inválido (null)
     */
    public void registraNota(Avaliável avaliado, Nota nota) throws AvaliávelInválidoException, NotaInválidaException {
        if (avaliado == null) {
            throw new AvaliávelInválidoException("");
        }
        if (nota == null) {
            throw new NotaInválidaException("");
        }
        if(!notas.containsKey(avaliado)) notas.put(avaliado, nota);
    }

    /**
     * Retorna a média das notas desta avaliação
     *
     * @return Um double contendo as notas
     */
    public double media() {
        double media = 0;
        for (Nota n : notas.values()) {
            media += n.getValor();
        }
        return media / (double)notas.size();
    }

    @Override
    public String toString() {
        return this.código + " - " + this.nome + "  \t(Data: " + data.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) + ")";
    }

    /**
     * Compara duas avaliações pelo código
     * 
     * @param outraAvaliação Avaliação com a qual se deseja comparar esta
     * @return      <pre>
     *  Um inteiro 'i' para os seguintes casos:
     *      i &gt; 0  - Caso seja o código desta avaliação seja lecoxigráficamente
     *               maior que o da outra
     *
     *      i == 0 - Caso os códigos das avaliação sejam iguais
     *
     *      i &lt; 0  - Caso seja o código desta avaliação seja lecoxigráficamente
     *               menor que o da outra
     * </pre>
     */
    @Override
    public int compareTo(Avaliação outraAvaliação) {
        return código.compareTo(outraAvaliação.código);
    }

    @Override
    public boolean equals(Object outraAvaliação) {
        Avaliação outra = (Avaliação)outraAvaliação;
        return código == outra.código;
    }
}
